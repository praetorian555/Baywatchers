/** 
*   @file:    EUROBOT_Servo.c
*   @author:  Cuvari plaze (Baywatcher & Praetorian)
*   @version: v2.031116.0000 (Baywatcher & Praetorian)
*   @date:    03/11/2016
*   @brief:   Definicije funkcija za upravljanje servo motorom.
*/


#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "EUROBOT_Servo.h"



// Globalne promenljive.
extern int time_delay = 0;



/**
* @brief: Pomeranje servo motora u zeljenu poziciju.
* @param: TIMx predstavlja pokazivac na tajmer kojem pripada capture-compare registar koji
*         kontrolise servo.
* @param: channel odredjuje koji tacno kanal u TIMx kontrolise servo.
* @param: position predstavlja ugao na koji zelimo da postavimo servo motor. Ugao
*         se gleda u odnosu na negativnu x-osu i raste u smeru kazaljke na satu. Vrednosti 
*         mogu biti sve celobrojne vrednosti iz opsega [0, 180].
* @return: Nema povratne vrednosti.
*
**/
void Servo_SetPosition(TIM_TypeDef *TIMx, uint16_t channel, int position)
{
  // Pokazivac na capture-compare registar koji kontorlise servo i predstavlja njegovu
  // trenutnu poziciju.
  uint16_t volatile *CCR;
  
  // Lociranje capture-compare registra koji kontrolise servo.
  if (channel == TIM_Channel_1) CCR = &(TIMx->CCR1);
  if (channel == TIM_Channel_2) CCR = &(TIMx->CCR2);
  if (channel == TIM_Channel_3) CCR = &(TIMx->CCR3);
  if (channel == TIM_Channel_4) CCR = &(TIMx->CCR4);
  if (CCR == 0) return;  // zasto ovo?
  
  position += 60;
  int step = 1;
  
  // Provera da li smo vec u zeljenoj poziciji.
  if (position == *CCR) return;
  // Po default-u smer kretanja motora je u smeru kazaljke na casovniku, pa se ovde 
  // proverava da li se treba kretati u suprotnom smeru (jer servo ne moze da opise ceo krug).
  else if (position < *CCR) step = -1;
  
  while(1)
  {
    // Promena trenutne pozicije.
    *CCR += step;
    
    // Ubacivanje kasnjenja posle izdavanja naredbe servu da bi stigao da zadate pozicije.
    delay(10);
    
    // Provera da li je servo stigao u zeljenu poziciju.
    if (*CCR == position) break;
  }  
}

/**
* @brief: Ova funkcja unosi zeljeno kasnjenje u sistem.
* @param: nTime predstavlja trajanje kasnjenja u milisekundama.
* @return: Nema povratne vrednosti.
*
**/
void delay(int nTime)
{
  // Promenljiva timeDelay se menja u SysTick_Handler-u.
  time_delay = nTime;
  while(time_delay != 0);
}

/**
* @brief: Pomocna funkcija za dekrementiranje globalne promenljive time_delay.
* @note:  Ovu funkciju treba pozvati u onoj prekidnoj rutini koja generise prekide
*         na 1 ms-u.
* @param: Nema argumenata.
* @return: Nema povratne vrednosti.
*
**/
void delay_decrement()
{
  /*if(time_delay != 0)*/ time_delay--;
}
