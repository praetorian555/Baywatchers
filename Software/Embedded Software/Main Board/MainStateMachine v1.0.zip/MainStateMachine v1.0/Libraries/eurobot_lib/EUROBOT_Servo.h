/** 
*   @file:    EUROBOT_Init.h
*   @author:  Cuvari plaze(Praetorian)
*   @version: v1.01.030816.0347 (Praetorian)
*   @date:    03/08/2016
*   @brief:   Deklaracije funkcija za inicijalizaciju periferija.
*/


#ifndef __EUROBOT_SERVO_H__
#define __EUROBOT_SERVO_H__

// Postavlja servo u zeljenu poziciju.
void Servo_SetPosition(TIM_TypeDef *TIMx, uint16_t channel, int position);
// Unosi zeljeno kasnjenje u sistem.
void delay(int);
// Dekrementira globalnu promenljivu koja predstavlja kasnjenje u sistemu svaki put kad je pozvana
// dok promenljiva ne padne na nulu.
void delay_decrement();

#endif