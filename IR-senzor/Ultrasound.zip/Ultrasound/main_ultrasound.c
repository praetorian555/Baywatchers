/**
  ******************************************************************************
  * @file    Examples/GPIOToggle/main.c 
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    09/13/2010
  * @brief   Main program body.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_conf.h"
#include "EUROBOT_Init.h"

//Deklaracija struktura
ADC_InitTypeDef ADC_InitStructure;

//promenljive
__IO uint32_t ADCValue;
uint32_t mean_ADCvalue;

int main(void)
{
  /*Inicijalizacija clock-a za ADC*/
  
  RCC_ADCCLKConfig(RCC_PCLK2_Div2); // DIV2 znaci da PCLK2 clock delim sa dva, i to je clk za ADC
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1| RCC_APB2Periph_GPIOA, ENABLE);
  
  /*Inicijalizacija ulaznog pina (analogni ulaz)*/
  
  InitGPIOPin(GPIOC, GPIO_Pin_4, GPIO_Mode_AIN, GPIO_Speed_50MHz);
  
  /*Inicijalizacija tajmera*/
  //korak je 0.5ms, a period je 50ms... duty cycle je 50%
  InitTIM_TimeBase(TIM2, 12000 - 1, 100 - 1, TIM_CounterMode_Up, TIM_CKD_DIV1, 0x00);
  InitTIM_OC(TIM2, TIM_Channel_2, TIM_OutputState_Enable, TIM_OCMode_PWM1, 50, TIM_OCPolarity_High);
  
  /*Konfiguracija ADC*/
  
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_CC2; //timer2
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStructure);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_1Cycles5);//inicijalizacija kanala, koji je vezan na PC4
  ADC_Cmd(ADC1, ENABLE);
  ADC_ResetCalibration(ADC1);//kalibracija
  while(ADC_GetResetCalibrationStatus(ADC1));
  ADC_StartCalibration(ADC1);
  while(ADC_GetCalibrationStatus(ADC1));  
  ADC_ExternalTrigConvCmd(ADC1,ENABLE);
  
  // nemam pojma zasto :D pise kod Jovicica //
  TIM2->CCR2=0x44;
  ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);
  
  //prekidi
  
  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_InitStructure.NVIC_IRQChannel = ADC1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
 while (1) {
  }
}


